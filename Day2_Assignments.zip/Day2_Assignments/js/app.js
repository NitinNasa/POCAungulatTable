//declare main module and its dependencies
var myModule = angular.module('myModule',['controllers']);
