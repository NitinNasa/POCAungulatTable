var controllers = angular.module('controllers',[]);
controllers.controller('ContactCtrl',function($scope){

	//$scope.password="";
	
	//var password="";
	
	$scope.validate = function(name,password) {
	   if(name=="stud101"){
		   if(password==name)
			   alert("login success");
	   }else if(name=="stud102"){

		   if(password==name)
			   alert("login success");
	   }else if(name=="librarian"){

		   if(password=="lib@123")
			   alert("login success");
	   }else{
		   alert("Please provide valid login credentials");
	   }
		   
	};

	
});


controllers.controller('BookListCtrl',function($scope){

	$scope.bookList=[

	 {"bookId":101,"bookTitle":"Angular Js","topic":"Angular Js","author":"Green","cost":"371","imgUrl":"images/AngularJS1.","issued":true},
	 {"bookId":102,"bookTitle":"Angular Js","topic":"Angular Js","author":"Green","cost":"372","imgUrl":"images/AngularJS2.JPG","issued":true},
	 {"bookId":103,"bookTitle":"Angular Js","topic":"Angular Js","author":"Green","cost":"373","imgUrl":"images/AngularJS3.JPG","issued":true},
	 {"bookId":104,"bookTitle":"Angular Js","topic":"Angular Js","author":"Green","cost":"374","imgUrl":"images/BackboneJS1.JPG","issued":true},
	 {"bookId":105,"bookTitle":"Angular Js","topic":"Angular Js","author":"Green","cost":"375","imgUrl":"images/BackboneJS2.JPG","issued":true},
	 {"bookId":106,"bookTitle":"Angular Js","topic":"Angular Js","author":"Green","cost":"376","imgUrl":"images/BackboneJS3.JPG","issued":true},
	 {"bookId":107,"bookTitle":"Angular Js","topic":"Angular Js","author":"Green","cost":"377","imgUrl":"images/DefaultBookImage.JPG","issued":true},
	 {"bookId":108,"bookTitle":"Angular Js","topic":"Angular Js","author":"Green","cost":"378","imgUrl":"images/EmberJS1.JPG","issued":true},
	 {"bookId":109,"bookTitle":"Angular Js","topic":"Angular Js","author":"Green","cost":"379","imgUrl":"images/EmberJS2.JPG","issued":true},
	 {"bookId":110,"bookTitle":"Angular Js","topic":"Angular Js","author":"Green","cost":"370","imgUrl":"images/EmberJS3.JPG","issued":true},
	 {"bookId":111,"bookTitle":"Angular Js","topic":"Angular Js","author":"Green","cost":"321","imgUrl":"images/NodeJS1.JPG","issued":true},
	 {"bookId":112,"bookTitle":"Angular Js","topic":"Angular Js","author":"Green","cost":"323","imgUrl":"images/NodeJS2.JPG","issued":true},
 ]
 
 $scope.dataset = [{"companyName":"PG&E","regions":[{"regionName":"USA","substations":[{"substationName":"California","feeder":[{"feederName":"Burlingame","sites":[{"siteName":"Main St","sensors":[{"id":"RE123456","phase":"A","autoPhase":"A","conflict":false,"conflictreason":"site duplicate"},{"id":"RE123456","phase":"B","autoPhase":"B","conflict":false},{"id":"RE1234562","phase":"C","autoPhase":"C","conflict":false}]},{"siteName":"Massey St","sensors":[{"id":"RE12346","phase":"A","autoPhase":"A","conflict":false},{"id":"RE123456","phase":"B","autoPhase":"B","conflict":false},{"id":"RE123456","phase":"C","autoPhase":"C","conflict":false}]}]},{"feederName":"Santa Clara","sites":[{"siteName":"Rodriquez St","sensors":[{"id":"5818bc56a0fc6bbb47f8a2fd","phase":"A","autoPhase":"C","conflict":true},{"id":"RE123456","phase":"B","autoPhase":"B","conflict":false},{"id":"RE123456","phase":"C","autoPhase":"A","conflict":true}]},{"siteName":"Boyle St","sensors":[{"id":"RE123456","phase":"A","autoPhase":"A","conflict":false},{"id":"RE123456","phase":"B","autoPhase":"B","conflict":false},{"id":"RE123456","phase":"C","autoPhase":"C","conflict":false}]}]}]},{"substationName":"Utah","feeder":[{"feederName":"Salt Lake City","sites":[{"siteName":"Hunt St","sensors":[{"id":"RE123456","phase":"A","autoPhase":"B","conflict":true},{"id":"RE123456","phase":"B","autoPhase":"A","conflict":true},{"id":"5818bc56d18599ffe917fb54","phase":"C","autoPhase":"C","conflict":false}]},{"siteName":"Stein St","sensors":[{"id":"5818bc565c220a98fad8ae49","phase":"A","autoPhase":"A","conflict":false},{"id":"RE123456","phase":"B","autoPhase":"B","conflict":true},{"id":"RE1256","phase":"C","autoPhase":"C","conflict":false}]}]},{"feederName":"Ogden","sites":[{"siteName":"Sutton St","sensors":[{"id":"5818bc56efd5b260067a7b58","phase":"A","autoPhase":"A","conflict":false},{"id":"RE123456","phase":"B","autoPhase":"B","conflict":false},{"id":"RE123456","phase":"C","autoPhase":"C","conflict":false}]},{"siteName":"Nicholson St","sensors":[{"id":"5818bc564998eabebd795ab0","phase":"A","autoPhase":"A","conflict":false},{"id":"5818bc565959005492577e09","phase":"B","autoPhase":"B","conflict":false},{"id":"5818bc5687ec6ab28678247c","phase":"C","autoPhase":"C","conflict":false}]}]}]}]},{"regionName":"India","substations":[{"substationName":"Karnatka","feeder":[{"feederName":"Bangalore","sites":[{"siteName":"Main St","sensors":[{"id":"5818bc5693b14b1d2414ac2f","phase":"A","autoPhase":"A","conflict":false},{"id":"5818bc56420cb22e46386357","phase":"B","autoPhase":"B","conflict":false},{"id":"5818bc56183da720087d1fb5","phase":"C","autoPhase":"C","conflict":false}]},{"siteName":"Sesond St","sensors":[{"id":"5818bc567dff6817a3dfae57","phase":"A","autoPhase":"A","conflict":false},{"id":"5818bc56a6b6520c5222dc90","phase":"B","autoPhase":"B","conflict":false},{"id":"5818bc56265c4617c805d0f3","phase":"C","autoPhase":"C","conflict":false}]}]},{"feederName":"Mysore","sites":[{"siteName":"Bright St","sensors":[{"id":"5818bc5689ad54e759a25eda","phase":"A","autoPhase":"A","conflict":false},{"id":"5818bc56b718669cecc6c7d7","phase":"B","autoPhase":"B","conflict":false},{"id":"5818bc56509973b9757b9ee8","phase":"C","autoPhase":"C","conflict":false}]},{"siteName":"Payne St","sensors":[{"id":"5818bc56ec5c1795d17b8fbb","phase":"A","autoPhase":"A","conflict":false},{"id":"5818bc5650dfa54ec39da1eb","phase":"B","autoPhase":"B","conflict":false},{"id":"5818bc564aeaeabf75c346a2","phase":"C","autoPhase":"C","conflict":false}]}]}]},{"substationName":"Punjab","feeder":[{"feederName":"Patiala","sites":[{"siteName":"Burt St","sensors":[{"id":"5818bc56d40293e0340c7d22","phase":"A","autoPhase":"A","conflict":false},{"id":"5818bc56ed3d3f804324393e","phase":"B","autoPhase":"B","conflict":false},{"id":"5818bc56bb20842694a58802","phase":"C","autoPhase":"C","conflict":false}]},{"siteName":"Dixon St","sensors":[{"id":"5818bc562622ebd30d31ff66","phase":"A","autoPhase":"A","conflict":false},{"id":"5818bc56e5660a26e187e071","phase":"B","autoPhase":"B","conflict":false},{"id":"5818bc56a86eb445541755ec","phase":"C","autoPhase":"C","conflict":false}]}]},{"feederName":"Amritsar","sites":[{"siteName":"Webster St","sensors":[{"id":"5818bc5666fb27b710fac0ef","phase":"A","autoPhase":"A","conflict":false},{"id":"5818bc5667cc4ffe7ef6b7bd","phase":"B","autoPhase":"B","conflict":false},{"id":"5818bc56340501a4c4090c14","phase":"C","autoPhase":"C","conflict":false}]},{"siteName":"Dorsey St","sensors":[{"id":"5818bc5610efb86183f604dc","phase":"A","autoPhase":"A","conflict":false},{"id":"5818bc56c72a91d3435f8628","phase":"B","autoPhase":"B","conflict":false},{"id":"5818bc5635cb3532087c79e8","phase":"C","autoPhase":"C","conflict":false}]}]}]}]}]}];
	
//console.log("Maninder dataset after change <br> " + $scope.dataset);
	
	$scope.jsonSubStation= [];
    $scope.valueJson = $scope.dataset[0].regions;
	for(var key in $scope.valueJson){
	alert("key is.."+JSON.stringify($scope.valueJson[key]));
	var regions=$scope.valueJson[key];
	for(var keys in  regions){
	console.log("key.."+keys+"..value.."+JSON.stringify(regions[keys]));
	if(JSON.stringify(regions[keys])=='regionName'){
	}else{
	
	}
	
	}
	}

});
/*
 * declare LoginCtrl 
 * Code description for LoginCtrl:
        Method1:
            validate(user): validates entered username and password and alerts appropriate messages
 */

/*
 * declare BookListCtrl 
 * Code description for BookListCtrl:
        Hard code book details in json array and store this in a books model
 */
 
